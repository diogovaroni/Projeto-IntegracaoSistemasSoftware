package com.example.cadastros.Aluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
